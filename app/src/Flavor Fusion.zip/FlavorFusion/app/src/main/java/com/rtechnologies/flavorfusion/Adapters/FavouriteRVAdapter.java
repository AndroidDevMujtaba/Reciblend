package com.rtechnologies.flavorfusion.Adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageSwitcher;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.rtechnologies.flavorfusion.Models.FavouriteModel;
import com.rtechnologies.flavorfusion.R;

import java.util.ArrayList;

public class FavouriteRVAdapter extends RecyclerView.Adapter<FavouriteRVAdapter.MyViewHolder> {

    ArrayList<FavouriteModel> favouriteArrayList;
    Context context;

    public FavouriteRVAdapter(ArrayList<FavouriteModel> favouriteArrayList, Context context) {
        this.favouriteArrayList = favouriteArrayList;
        this.context = context;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.favourite_recyclerview_design, parent,false);
        return new FavouriteRVAdapter.MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {

        // setting data
        holder.recipeImageFav.setImageResource(favouriteArrayList.get(position).getRecipeImageFav());
        holder.bookmarkImage.setImageResource(favouriteArrayList.get(position).getBookmarkImage());
        holder.starImageFav.setImageResource(favouriteArrayList.get(position).getStarImageFav());
        holder.recipeNameFav.setText(favouriteArrayList.get(position).getRecipeNameFav());
        holder.recipeRating.setText(favouriteArrayList.get(position).getRecipeRating());

    }

    @Override
    public int getItemCount() {
        return favouriteArrayList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {


        public ImageView recipeImageFav, bookmarkImage,starImageFav;
        public TextView recipeNameFav, recipeRating;


        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            recipeImageFav = itemView.findViewById(R.id.iv_recipeImage_fav);
            bookmarkImage = itemView.findViewById(R.id.iv_bookmarkImage_fav);
            starImageFav = itemView.findViewById(R.id.iv_star_fav);
            recipeNameFav = itemView.findViewById(R.id.tv_recipeName_fav);
            recipeRating = itemView.findViewById(R.id.rating_fav);
        }
    }
}
