package com.rtechnologies.flavorfusion.Models;

public class FavouriteModel {

    private int recipeImageFav;
    private int bookmarkImage;
    private int starImageFav;
    private String recipeNameFav;
    private String recipeRating;

    public FavouriteModel(int recipeImageFav, int bookmarkImage, int starImageFav, String recipeNameFav, String recipeRating) {
        this.recipeImageFav = recipeImageFav;
        this.bookmarkImage = bookmarkImage;
        this.starImageFav = starImageFav;
        this.recipeNameFav = recipeNameFav;
        this.recipeRating = recipeRating;
    }

    public int getRecipeImageFav() {
        return recipeImageFav;
    }

    public void setRecipeImageFav(int recipeImageFav) {
        this.recipeImageFav = recipeImageFav;
    }

    public int getBookmarkImage() {
        return bookmarkImage;
    }

    public void setBookmarkImage(int bookmarkImage) {
        this.bookmarkImage = bookmarkImage;
    }

    public int getStarImageFav() {
        return starImageFav;
    }

    public void setStarImageFav(int starImageFav) {
        this.starImageFav = starImageFav;
    }

    public String getRecipeNameFav() {
        return recipeNameFav;
    }

    public void setRecipeNameFav(String recipeName) {
        this.recipeNameFav = recipeNameFav;
    }

    public String getRecipeRating() {
        return recipeRating;
    }

    public void setRecipeRating(String recipeRating) {
        this.recipeRating = recipeRating;
    }
}
